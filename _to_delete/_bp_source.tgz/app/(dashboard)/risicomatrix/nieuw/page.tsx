import Link from "next/link";
import NieuwRisicoForm from "../_components/NieuwRisicoForm";

export default function NieuwRisicoPage() {
  return (
    <div className="p-4 sm:p-6 lg:p-7 max-w-3xl">
      <Link
        href="/risicomatrix"
        className="text-sm text-muted hover:text-ink inline-flex items-center gap-1"
      >
        ← Terug naar matrix
      </Link>
      <h1 className="font-serif text-ink text-xl font-bold mt-2">
        Nieuw risico vastleggen
      </h1>
      <p className="text-muted text-sm mt-0.5">
        Geef een titel, kies een categorie, en bepaal kans en impact. Het
        risiconiveau wordt automatisch afgeleid &mdash; je kunt het
        handmatig overschrijven indien nodig.
      </p>
      <div className="mt-6">
        <NieuwRisicoForm />
      </div>
    </div>
  );
}
