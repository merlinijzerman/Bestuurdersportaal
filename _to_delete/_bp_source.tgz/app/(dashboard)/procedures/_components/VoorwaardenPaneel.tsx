"use client";

// Client-component: voorwaarden-paneel voor het Decision Object.
//
// Voorwaarden bij een (voorwaardelijk) besluit: KPI, drempelwaarde,
// monitorfrequentie, deadline, heroverwegingstrigger. Status-cyclus
// open → op_schema → afwijking → vervuld; aparte knop voor
// 'overschreden'.

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  type ConditionStatus,
  type DecisionCondition,
  CONDITION_STATUS_LABEL,
} from "@/core/lib/decision-view";

interface Props {
  decisionId: string;
  conditions: DecisionCondition[];
}

const STATUS_CYCLUS: ConditionStatus[] = [
  "open",
  "op_schema",
  "afwijking",
  "vervuld",
];

function statusKleur(s: ConditionStatus): string {
  switch (s) {
    case "vervuld":
      return "bg-ok-tint text-ok-ink border-ok/30";
    case "op_schema":
      return "bg-accent-tint text-accent-ink border-accent/30";
    case "afwijking":
      return "bg-warn-tint text-warn-ink border-warn/30";
    case "overschreden":
      return "bg-err-tint text-err-ink border-err/30";
    default:
      return "bg-app-bg text-ink border-line";
  }
}

function formatDatum(d: string | null): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("nl-NL", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export default function VoorwaardenPaneel({ decisionId, conditions }: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [bezig, setBezig] = useState<string | null>(null);
  const [fout, setFout] = useState<string | null>(null);

  const [voorwaarde, setVoorwaarde] = useState("");
  const [eigenaar, setEigenaar] = useState("");
  const [kpi, setKpi] = useState("");
  const [drempel, setDrempel] = useState("");
  const [monitor, setMonitor] = useState("");
  const [deadline, setDeadline] = useState("");
  const [trigger, setTrigger] = useState("");

  // ── Inline-edit-state (Iteratie 3-C) ─────────────────────────
  const [editId, setEditId] = useState<string | null>(null);
  const [editVoorwaarde, setEditVoorwaarde] = useState("");
  const [editEigenaar, setEditEigenaar] = useState("");
  const [editKpi, setEditKpi] = useState("");
  const [editDrempel, setEditDrempel] = useState("");
  const [editMonitor, setEditMonitor] = useState("");
  const [editDeadline, setEditDeadline] = useState("");
  const [editTrigger, setEditTrigger] = useState("");

  function startBewerken(c: DecisionCondition) {
    setEditId(c.id);
    setEditVoorwaarde(c.voorwaarde);
    setEditEigenaar(c.eigenaar_naam ?? "");
    setEditKpi(c.kpi ?? "");
    setEditDrempel(c.drempelwaarde ?? "");
    setEditMonitor(c.monitorfrequentie ?? "");
    setEditDeadline(c.deadline ?? "");
    setEditTrigger(c.heroverwegingstrigger ?? "");
    setFout(null);
  }

  function annuleerBewerken() {
    setEditId(null);
    setFout(null);
  }

  async function bewaarBewerken(c: DecisionCondition) {
    if (!editVoorwaarde.trim()) {
      setFout("Voorwaarde is verplicht");
      return;
    }
    setBezig(c.id);
    setFout(null);
    try {
      const payload: Record<string, unknown> = {};
      const nieuw = editVoorwaarde.trim();
      if (nieuw !== c.voorwaarde) payload.voorwaarde = nieuw;
      const nieuweEig: string | null = editEigenaar.trim() || null;
      if (nieuweEig !== (c.eigenaar_naam ?? null))
        payload.eigenaar_naam = nieuweEig;
      const nieuweKpi: string | null = editKpi.trim() || null;
      if (nieuweKpi !== (c.kpi ?? null)) payload.kpi = nieuweKpi;
      const nieuweDr: string | null = editDrempel.trim() || null;
      if (nieuweDr !== (c.drempelwaarde ?? null))
        payload.drempelwaarde = nieuweDr;
      const nieuweMon: string | null = editMonitor.trim() || null;
      if (nieuweMon !== (c.monitorfrequentie ?? null))
        payload.monitorfrequentie = nieuweMon;
      const nieuweDeadline: string | null = editDeadline || null;
      if (nieuweDeadline !== (c.deadline ?? null))
        payload.deadline = nieuweDeadline;
      const nieuweTrig: string | null = editTrigger.trim() || null;
      if (nieuweTrig !== (c.heroverwegingstrigger ?? null))
        payload.heroverwegingstrigger = nieuweTrig;

      if (Object.keys(payload).length === 0) {
        annuleerBewerken();
        return;
      }

      const res = await fetch(
        `/api/decisions/${decisionId}/conditions/${c.id}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Wijzigen mislukt");
      annuleerBewerken();
      router.refresh();
    } catch (e) {
      setFout(e instanceof Error ? e.message : "Onbekende fout");
    } finally {
      setBezig(null);
    }
  }

  async function nieuw() {
    if (!voorwaarde.trim()) {
      setFout("Voorwaarde is verplicht");
      return;
    }
    setBezig("nieuw");
    setFout(null);
    try {
      const res = await fetch(`/api/decisions/${decisionId}/conditions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voorwaarde: voorwaarde.trim(),
          eigenaar_naam: eigenaar.trim() || null,
          kpi: kpi.trim() || null,
          drempelwaarde: drempel.trim() || null,
          monitorfrequentie: monitor.trim() || null,
          deadline: deadline || null,
          heroverwegingstrigger: trigger.trim() || null,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Toevoegen mislukt");
      setVoorwaarde("");
      setEigenaar("");
      setKpi("");
      setDrempel("");
      setMonitor("");
      setDeadline("");
      setTrigger("");
      setOpen(false);
      router.refresh();
    } catch (e) {
      setFout(e instanceof Error ? e.message : "Onbekende fout");
    } finally {
      setBezig(null);
    }
  }

  async function patchStatus(c: DecisionCondition, nieuweStatus: ConditionStatus) {
    setBezig(c.id);
    setFout(null);
    try {
      const res = await fetch(
        `/api/decisions/${decisionId}/conditions/${c.id}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: nieuweStatus }),
        }
      );
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Wijzigen mislukt");
      router.refresh();
    } catch (e) {
      setFout(e instanceof Error ? e.message : "Onbekende fout");
    } finally {
      setBezig(null);
    }
  }

  function cyclusStatus(c: DecisionCondition) {
    if (c.status === "overschreden") return; // klikken op overschreden doet niets
    const idx = STATUS_CYCLUS.indexOf(c.status as ConditionStatus);
    if (idx === -1) {
      void patchStatus(c, "open");
      return;
    }
    const volgende = STATUS_CYCLUS[(idx + 1) % STATUS_CYCLUS.length];
    void patchStatus(c, volgende);
  }

  return (
    <div className="bg-white border border-line rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold text-ink">Voorwaarden</h3>
          <p className="text-xs text-muted mt-0.5">
            Voorwaarden waaronder dit besluit van kracht is — met KPI,
            drempelwaarde en heroverwegingstrigger.
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            setOpen((o) => !o);
            setFout(null);
          }}
          className="text-xs text-ink hover:underline whitespace-nowrap"
        >
          {open ? "Sluiten" : "+ Nieuwe voorwaarde"}
        </button>
      </div>

      {open && (
        <div className="mb-4 border border-line rounded-lg p-4 bg-app-bg/50 space-y-3">
          <Veldgroep label="Voorwaarde *">
            <textarea
              value={voorwaarde}
              onChange={(e) => setVoorwaarde(e.target.value)}
              rows={2}
              className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
              placeholder="Bijv. 'Allocatie naar zakelijke waarden blijft binnen mandaatbandbreedte 35-45%.'"
            />
          </Veldgroep>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Veldgroep label="KPI">
              <input
                type="text"
                value={kpi}
                onChange={(e) => setKpi(e.target.value)}
                className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                placeholder="bijv. allocatie zakelijke waarden"
              />
            </Veldgroep>
            <Veldgroep label="Drempelwaarde">
              <input
                type="text"
                value={drempel}
                onChange={(e) => setDrempel(e.target.value)}
                className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                placeholder="35–45%"
              />
            </Veldgroep>
            <Veldgroep label="Monitorfrequentie">
              <input
                type="text"
                value={monitor}
                onChange={(e) => setMonitor(e.target.value)}
                className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                placeholder="maandelijks"
              />
            </Veldgroep>
            <Veldgroep label="Deadline">
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
              />
            </Veldgroep>
          </div>
          <Veldgroep label="Eigenaar">
            <input
              type="text"
              value={eigenaar}
              onChange={(e) => setEigenaar(e.target.value)}
              className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
              placeholder="Wie bewaakt deze voorwaarde?"
            />
          </Veldgroep>
          <Veldgroep label="Heroverwegingstrigger">
            <input
              type="text"
              value={trigger}
              onChange={(e) => setTrigger(e.target.value)}
              className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
              placeholder="Wanneer moet dit besluit opnieuw besproken worden? Bijv. 'bij overschrijden 6 maanden'"
            />
          </Veldgroep>
          {fout && (
            <div className="text-xs text-err-ink bg-err-tint border border-err/30 rounded-md px-3 py-2">
              {fout}
            </div>
          )}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={nieuw}
              disabled={bezig === "nieuw"}
              className="bg-accent text-white text-sm px-4 py-2 rounded-md hover:bg-accent-ink disabled:opacity-50"
            >
              {bezig === "nieuw" ? "Bezig…" : "Toevoegen"}
            </button>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                setFout(null);
              }}
              className="text-sm text-muted hover:text-ink px-3 py-2"
            >
              Annuleer
            </button>
          </div>
        </div>
      )}

      {conditions.length === 0 ? (
        <div className="text-sm text-muted italic">
          Nog geen voorwaarden vastgelegd. Bij voorwaardelijke besluiten zijn
          deze verplicht voor verantwoordingsrijp.
        </div>
      ) : (
        <ul className="space-y-3">
          {conditions.map((c) => (
            <li
              key={c.id}
              className={`border rounded-lg p-3 ${
                editId === c.id
                  ? "border-accent bg-warn-tint"
                  : "border-line bg-white"
              }`}
            >
              {editId === c.id ? (
                // ── Inline edit-form ───────────────────────────
                <div className="space-y-3">
                  <Veldgroep label="Voorwaarde *">
                    <textarea
                      value={editVoorwaarde}
                      onChange={(e) => setEditVoorwaarde(e.target.value)}
                      rows={2}
                      className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                    />
                  </Veldgroep>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Veldgroep label="KPI">
                      <input
                        type="text"
                        value={editKpi}
                        onChange={(e) => setEditKpi(e.target.value)}
                        className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                      />
                    </Veldgroep>
                    <Veldgroep label="Drempelwaarde">
                      <input
                        type="text"
                        value={editDrempel}
                        onChange={(e) => setEditDrempel(e.target.value)}
                        className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                      />
                    </Veldgroep>
                    <Veldgroep label="Monitorfrequentie">
                      <input
                        type="text"
                        value={editMonitor}
                        onChange={(e) => setEditMonitor(e.target.value)}
                        className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                      />
                    </Veldgroep>
                    <Veldgroep label="Deadline">
                      <input
                        type="date"
                        value={editDeadline}
                        onChange={(e) => setEditDeadline(e.target.value)}
                        className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                      />
                    </Veldgroep>
                  </div>
                  <Veldgroep label="Eigenaar">
                    <input
                      type="text"
                      value={editEigenaar}
                      onChange={(e) => setEditEigenaar(e.target.value)}
                      className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                    />
                  </Veldgroep>
                  <Veldgroep label="Heroverwegingstrigger">
                    <input
                      type="text"
                      value={editTrigger}
                      onChange={(e) => setEditTrigger(e.target.value)}
                      className="w-full text-sm border border-app-line-strong rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-accent/40"
                    />
                  </Veldgroep>
                  {fout && (
                    <div className="text-xs text-err-ink bg-err-tint border border-err/30 rounded-md px-3 py-2">
                      {fout}
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => bewaarBewerken(c)}
                      disabled={bezig === c.id}
                      className="bg-accent text-white text-sm px-4 py-2 rounded-md hover:bg-accent-ink disabled:opacity-50"
                    >
                      {bezig === c.id ? "Bezig…" : "Bewaar"}
                    </button>
                    <button
                      type="button"
                      onClick={annuleerBewerken}
                      disabled={bezig === c.id}
                      className="text-sm text-muted hover:text-ink px-3 py-2"
                    >
                      Annuleer
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-ink whitespace-pre-line">
                    {c.voorwaarde}
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-1 mt-2 text-xs">
                    {c.kpi && (
                      <div>
                        <span className="text-muted">KPI:</span>{" "}
                        <span className="text-ink">{c.kpi}</span>
                      </div>
                    )}
                    {c.drempelwaarde && (
                      <div>
                        <span className="text-muted">Drempel:</span>{" "}
                        <span className="text-ink">{c.drempelwaarde}</span>
                      </div>
                    )}
                    {c.monitorfrequentie && (
                      <div>
                        <span className="text-muted">Monitor:</span>{" "}
                        <span className="text-ink">
                          {c.monitorfrequentie}
                        </span>
                      </div>
                    )}
                    {c.deadline && (
                      <div>
                        <span className="text-muted">Deadline:</span>{" "}
                        <span className="text-ink">
                          {formatDatum(c.deadline)}
                        </span>
                      </div>
                    )}
                  </div>
                  {c.heroverwegingstrigger && (
                    <div className="text-xs text-ink mt-2 italic">
                      Heroverweging: {c.heroverwegingstrigger}
                    </div>
                  )}
                  {c.eigenaar_naam && (
                    <div className="text-xs text-muted mt-1">
                      Eigenaar: {c.eigenaar_naam}
                    </div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-1 min-w-[110px]">
                  <button
                    type="button"
                    onClick={() => cyclusStatus(c)}
                    disabled={bezig === c.id}
                    title="Klik om volgende status te kiezen"
                    className={`text-[11px] font-medium uppercase tracking-wide border px-2 py-0.5 rounded cursor-pointer hover:opacity-80 disabled:opacity-50 ${statusKleur(
                      c.status
                    )}`}
                  >
                    {CONDITION_STATUS_LABEL[c.status]}
                  </button>
                  {c.status !== "overschreden" && c.status !== "vervuld" && (
                    <button
                      type="button"
                      onClick={() => patchStatus(c, "overschreden")}
                      disabled={bezig === c.id}
                      className="text-[11px] text-err-ink hover:underline disabled:opacity-50"
                    >
                      Overschreden
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => startBewerken(c)}
                    disabled={bezig === c.id}
                    className="text-[11px] text-ink hover:underline disabled:opacity-50"
                    title="Voorwaarde bewerken"
                  >
                    Bewerk
                  </button>
                </div>
              </div>
              )}
            </li>
          ))}
        </ul>
      )}

      {fout && !open && (
        <div className="mt-3 text-xs text-err-ink bg-err-tint border border-err/30 rounded-md px-3 py-2">
          {fout}
        </div>
      )}
    </div>
  );
}

function Veldgroep({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="text-[11px] uppercase tracking-wide text-muted font-semibold block mb-1">
        {label}
      </label>
      {children}
    </div>
  );
}
