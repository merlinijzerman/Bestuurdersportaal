import { randomUUID } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/core/lib/supabase-server";
// F6: extractie/OCR/chunking/caps/samenvatting draaien in de async worker
// (platform/lib/ingest-orchestrator). F7 (direct-to-storage): het bestand gaat
// rechtstreeks browser→Storage (langs de Vercel-body-limiet heen); deze route
// gate't de metadata (init) en valideert+registreert het geüploade object
// (complete). Zie core/lib/document-upload-client.ts voor de client-kant.
import {
  magOvergaan,
  redenVerplicht,
  toegestaneIngestStatussen,
  vereisteCapability,
  type DocumentStatus,
} from "@/core/lib/document-status-transities";
// Besluit 0140 — classificatie bij aanlevering (documenttype + bronstatus).
// Puur, gedeeld met de UI, en getest in document-ingest-classificatie.sanity.ts.
import {
  beoordeelIngestBronstatus,
  beoordeelIngestDocumenttype,
  beoordeelIngestDocumentdatum,
  VEREISTE_BRONSTATUS_CAPABILITY,
} from "@/core/lib/document-ingest-classificatie";
import type { Documenttype, DocumentContext } from "@/core/lib/document-metadata";
import { magVanKracht, NORMATIEVE_DOCUMENTTYPEN } from "@/core/lib/document-statusprofiel";
import { beoordeelRapportageRetire } from "@/core/lib/document-rapportage-retire";
import type { Bronstatus } from "@/core/lib/document-status-transities";
import { requireCapability, type Capability } from "@/core/lib/capabilities";
import {
  valideerUpload,
  logNaam,
  MAX_BESTAND_BYTES,
} from "@/core/lib/bestand-validatie";
import { toegestaneUploadExtensie } from "@/core/lib/ingest-caps";
import { controleerLimiet, LIMIETEN } from "@/core/lib/rate-limit";
import { badRequest, rateLimited } from "@/core/lib/api-errors";
import { beoordeelRouteHostToegang } from "@/core/lib/tenant-route-guard";

type ServerSupabase = Awaited<ReturnType<typeof createServerSupabase>>;

// Strip de bestandsextensie van de naam — werkt voor alle ondersteunde types.
function stripExtensie(naam: string): string {
  return naam.replace(/\.(pdf|docx|pptx|xlsx)$/i, "");
}

// Werkopdracht 2.5 — gevalideerde retire-gegevens die van de poort naar de
// uitvoering (completeUpload) reizen.
type RapportageRetireInfo = {
  voorgangerId: string;
  voorgangerOudeStatus: DocumentStatus;
  voorgangerTitel: string;
  reden: string;
};

// ── Gedeelde metadata-poort (init én complete) ─────────────────────────────
// F7: init gate't vóór de upload (geen verspilde upload bij een blokkade),
// maar complete maakt de documentrij en MOET daarom dezelfde poorten opnieuw
// draaien — nooit vertrouwen dat de client init eerlijk doorliep. Alle checks
// server-side (guardrail). Retourneert genormaliseerde velden of een respons.
type MetadataUitkomst =
  | {
      ok: true;
      bibliotheek: string;
      bron: string;
      titel: string;
      agendapunt_id: string | null;
      vergadering_id: string | null;
      // Werkopdracht 1.5 — afgeleide context (niet meer door de client gevraagd).
      context: DocumentContext;
      // Werkopdracht 1.4/1.5 — documentdatum: verplicht bij rapportage, anders
      // default op de uploaddatum.
      documentdatum: string;
      ingestStatus: DocumentStatus | null;
      statusReden: string | null;
      // Besluit 0140 — classificatie bij aanlevering.
      documenttype: Documenttype | null;
      bronstatus: Bronstatus | null;
      bronstatusReden: string | null;
      bronstatusRagImpact: boolean;
      // Werkopdracht 2.5 — rapportage-retire: de gekozen voorganger die bij
      // aanlevering van deze (actuele) rapportage naar `historisch` gaat.
      retire: RapportageRetireInfo | null;
      // Retire kon in de complete-fase niet (meer) — de upload slaagt wél; dit is
      // de melding die aan de gebruiker teruggaat.
      retireWaarschuwing: string | null;
    }
  | { ok: false; response: NextResponse };

async function valideerUploadMetadata(
  supabase: ServerSupabase,
  userId: string,
  fondsId: string,
  fase: "init" | "complete",
  raw: {
    bestandsnaam: string;
    agendapunt_id?: string | null;
    bibliotheek?: string | null;
    bron?: string | null;
    titel?: string | null;
    status?: string | null;
    status_reden?: string | null;
    documenttype?: string | null;
    documentdatum?: string | null;
    bronstatus?: string | null;
    bronstatus_reden?: string | null;
    vervangt_rapportage_id?: string | null;
    retire_reden?: string | null;
  }
): Promise<MetadataUitkomst> {
  const agendapunt_id = raw.agendapunt_id || null;
  let bibliotheek = raw.bibliotheek || null;
  let bron = raw.bron || null;
  let titel = raw.titel || null;

  // Wanneer dit een vergaderstuk is, zijn standaardwaarden voldoende.
  if (agendapunt_id) {
    bibliotheek = bibliotheek || "fonds";
    bron = bron || "Intern";
    titel = titel || (raw.bestandsnaam ? stripExtensie(raw.bestandsnaam) : "Vergaderstuk");
  }

  // B13: generieke (platform-gecureerde) documenten mogen NIET via de tenant-
  // uploadroute worden aangemaakt. Default = 'fonds'; server-side leidend.
  if (bibliotheek === "generiek") {
    return {
      ok: false,
      response: NextResponse.json(
        {
          error:
            "Generieke (platform-gecureerde) documenten kunnen niet door fondsen worden geüpload. Upload dit als fondsdocument.",
        },
        { status: 403 }
      ),
    };
  }
  bibliotheek = bibliotheek || "fonds";

  if (!bibliotheek || !bron || !titel) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "Verplichte velden ontbreken: bibliotheek, bron, titel" },
        { status: 400 }
      ),
    };
  }

  // -- Statusverklaring bij ingest (besluit 0136), drie server-side poorten ---
  const gevraagdeStatus = raw.status?.trim() || null;
  const statusReden = raw.status_reden?.trim() || null;
  let ingestStatus: DocumentStatus | null = null;

  if (gevraagdeStatus && gevraagdeStatus !== "concept") {
    const doelStatus = gevraagdeStatus as DocumentStatus;
    if (!magOvergaan("upload", doelStatus)) {
      return {
        ok: false,
        response: NextResponse.json(
          {
            error:
              `Status "${gevraagdeStatus}" kan niet bij aanlevering worden verklaard. ` +
              `Toegestaan: ${toegestaneIngestStatussen().join(", ")}.`,
            foutcode: "status_bij_ingest_ongeldig",
          },
          { status: 400 }
        ),
      };
    }
    const cap = vereisteCapability("upload", doelStatus);
    if (cap && cap !== "upload" && !(await requireCapability(userId, cap as Capability))) {
      return {
        ok: false,
        response: NextResponse.json(
          {
            error:
              "Onvoldoende rechten om bij aanlevering een status te verklaren. " +
              "Upload als concept en laat een beheerder of voorzitter de status zetten.",
          },
          { status: 403 }
        ),
      };
    }
    if (redenVerplicht("upload", doelStatus) && !statusReden) {
      return {
        ok: false,
        response: NextResponse.json(
          {
            error:
              "Geef een reden bij de statusverklaring -- bijvoorbeeld waar en wanneer " +
              "het stuk is vastgesteld. Die reden landt in het auditlog.",
            foutcode: "status_reden_ontbreekt",
          },
          { status: 400 }
        ),
      };
    }
    ingestStatus = doelStatus;
  }

  // -- Classificatie bij aanlevering (besluit 0140) ---------------------------
  // Documenttype is verplicht op het BIBLIOTHEEK-pad en optioneel wanneer de
  // upload uit een andere context komt (vergaderstuk bij een agendapunt,
  // bewijsstuk bij een processtap). Die stromen tonen de vraag niet, en er
  // automatisch "bijlage" van maken zou een classificatie verzinnen die we niet
  // kennen. Zie de toelichting in document-ingest-classificatie.ts.
  const typeUitkomst = beoordeelIngestDocumenttype(raw.documenttype, {
    verplicht: !agendapunt_id,
  });
  if (!typeUitkomst.ok) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: typeUitkomst.melding, foutcode: typeUitkomst.foutcode },
        { status: 400 }
      ),
    };
  }

  // Statusprofiel (werkopdracht 1.3, DOELMODEL §5): 'van kracht' is een geldende
  // NORM en mag alleen bij de normatieve cluster worden verklaard. Server-side
  // leidend, náást de UI-filter. Beide velden zijn hier bekend.
  if (ingestStatus === "van_kracht" && !magVanKracht(typeUitkomst.documenttype)) {
    return {
      ok: false,
      response: NextResponse.json(
        {
          error:
            `Status 'van kracht' is alleen toegestaan voor normatieve documenttypen ` +
            `(${NORMATIEVE_DOCUMENTTYPEN.join(", ")}). Kies 'vastgesteld' of pas het type aan.`,
          foutcode: "van_kracht_niet_toegestaan_voor_type",
        },
        { status: 400 }
      ),
    };
  }

  // -- Documentdatum (werkopdracht 1.4/1.5) -----------------------------------
  // Rapportage vereist een documentdatum; andere types defaulten op vandaag.
  const vandaag = new Date().toISOString().slice(0, 10);
  const datumUitkomst = beoordeelIngestDocumentdatum(
    typeUitkomst.documenttype,
    raw.documentdatum,
    vandaag
  );
  if (!datumUitkomst.ok) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: datumUitkomst.melding, foutcode: datumUitkomst.foutcode },
        { status: 400 }
      ),
    };
  }

  // Bronstatus loopt door DEZELFDE transitietabel als een latere wijziging, met
  // dezelfde capability. Zonder deze poort zou upload een achterdeur zijn om de
  // bronstatus-governance te omzeilen.
  const bronstatusUitkomst = beoordeelIngestBronstatus(
    raw.bronstatus,
    raw.bronstatus_reden
  );
  if (!bronstatusUitkomst.ok) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: bronstatusUitkomst.melding, foutcode: bronstatusUitkomst.foutcode },
        { status: 400 }
      ),
    };
  }
  if (
    bronstatusUitkomst.bronstatus &&
    !(await requireCapability(userId, VEREISTE_BRONSTATUS_CAPABILITY as Capability))
  ) {
    return {
      ok: false,
      response: NextResponse.json(
        {
          error:
            "Onvoldoende rechten om bij aanlevering een bronstatus te verklaren. " +
            "Upload zonder bronstatus en laat een beheerder of voorzitter hem zetten.",
          foutcode: "bronstatus_capability_ontbreekt",
        },
        { status: 403 }
      ),
    };
  }

  // Stuk bij een agendapunt: vergadering_id afleiden. De trigger
  // fn_document_agendapunt_vergadering_check eist gelijkheid (en niet NULL).
  let vergadering_id: string | null = null;
  if (agendapunt_id) {
    const { data: agendapuntRij, error: agendapuntError } = await supabase
      .from("agendapunten")
      .select("vergadering_id")
      .eq("id", agendapunt_id)
      .single();
    if (agendapuntError || !agendapuntRij) {
      return {
        ok: false,
        response: NextResponse.json(
          { error: "Agendapunt niet gevonden of geen toegang" },
          { status: 400 }
        ),
      };
    }
    vergadering_id = agendapuntRij.vergadering_id;
  }

  // Werkopdracht 1.5 — context volledig AFLEIDEN uit de FK-koppelingen i.p.v.
  // door de client laten aanleveren. Op dit uploadpad is alleen de
  // vergadering-koppeling beschikbaar (agendapunt → vergadering); de
  // dossier-/procesinstantiekoppeling ontstaat later via een aparte join en is
  // hier dus geen invoer. Vandaar: vergadering_id → 'vergadering', anders
  // 'algemeen'. Voldoet aan de context-CHECK-constraints (vergadering vereist
  // vergadering_id).
  const context: DocumentContext = vergadering_id ? "vergadering" : "algemeen";

  // -- Rapportage-retire (werkopdracht 2.5) -----------------------------------
  // Bij het aanleveren van een NIEUWE, actuele rapportage kan de uploader de op
  // te volgen rapportage kiezen; die gaat dan → historisch. Puur additief op het
  // 5-waarden-statusmodel (0154).
  //
  // FASE-verschil: in `init` is een retire-fout een BLOKKER (400 vóór de upload,
  // UX-guardrail). In `complete` is het bestand al direct-to-storage geland;
  // dan mag een retire-fout de geslaagde upload NIET kelderen — hij degradeert
  // naar een waarschuwing (de retire wordt overgeslagen).
  let retire: RapportageRetireInfo | null = null;
  let retireWaarschuwing: string | null = null;
  const vervangtId =
    typeof raw.vervangt_rapportage_id === "string"
      ? raw.vervangt_rapportage_id.trim() || null
      : null;
  if (vervangtId) {
    const uitkomst = await (async (): Promise<
      | { soort: "ok"; retire: RapportageRetireInfo }
      | { soort: "fout"; melding: string; foutcode: string }
    > => {
      if (typeUitkomst.documenttype !== "rapportage") {
        return {
          soort: "fout",
          melding: "Een voorganger afvoeren kan alleen bij het aanleveren van een rapportage.",
          foutcode: "retire_geen_rapportage",
        };
      }
      if (ingestStatus !== "vastgesteld" && ingestStatus !== "van_kracht") {
        return {
          soort: "fout",
          melding:
            "Verklaar de nieuwe rapportage als 'vastgesteld' of 'van kracht' om de vorige af te voeren.",
          foutcode: "retire_nieuwe_niet_actueel",
        };
      }
      const { data: voorganger } = await supabase
        .from("documenten")
        .select("id, fonds_id, documenttype, status, titel, actief")
        .eq("id", vervangtId)
        .maybeSingle();
      if (!voorganger || voorganger.fonds_id !== fondsId || voorganger.actief === false) {
        return {
          soort: "fout",
          melding: "De gekozen voorgaande rapportage is niet gevonden in dit fonds.",
          foutcode: "retire_voorganger_onbekend",
        };
      }
      const voorgangerStatus = (voorganger.status as DocumentStatus) ?? null;
      const beoordeling = beoordeelRapportageRetire({
        nieuwDocumenttype: typeUitkomst.documenttype,
        voorgangerDocumenttype: (voorganger.documenttype as Documenttype) ?? null,
        voorgangerStatus,
      });
      if (!beoordeling.ok) {
        return { soort: "fout", melding: beoordeling.melding, foutcode: beoordeling.foutcode };
      }
      // Defense-in-depth: expliciete capability-check op de retire-transitie zelf,
      // náást de impliciete afdwinging via de ingest-statuspoort. Divergeert de
      // vereiste capability ooit (bv. admin-only afvoer), dan blijft dit sluitend.
      const retireCap = vereisteCapability(voorgangerStatus as DocumentStatus, "historisch");
      if (
        retireCap &&
        retireCap !== "upload" &&
        !(await requireCapability(userId, retireCap as Capability))
      ) {
        return {
          soort: "fout",
          melding: "Onvoldoende rechten om de vorige rapportage af te voeren (documents.status.change).",
          foutcode: "retire_capability_ontbreekt",
        };
      }
      const opgegevenReden =
        typeof raw.retire_reden === "string" ? raw.retire_reden.trim() : "";
      return {
        soort: "ok",
        retire: {
          voorgangerId: voorganger.id as string,
          voorgangerOudeStatus: voorgangerStatus as DocumentStatus,
          voorgangerTitel: (voorganger.titel as string) ?? "",
          reden: opgegevenReden || `Opgevolgd door nieuwe rapportage: ${titel}`,
        },
      };
    })();

    if (uitkomst.soort === "ok") {
      retire = uitkomst.retire;
    } else if (fase === "init") {
      return {
        ok: false,
        response: NextResponse.json(
          { error: uitkomst.melding, foutcode: uitkomst.foutcode },
          { status: 400 }
        ),
      };
    } else {
      retireWaarschuwing = ` Let op: de vorige rapportage is niet afgevoerd — ${uitkomst.melding} Voer die eventueel handmatig af via 'Metadata bewerken'.`;
    }
  }

  return {
    ok: true,
    bibliotheek,
    bron,
    titel,
    agendapunt_id,
    vergadering_id,
    context,
    documentdatum: datumUitkomst.documentdatum,
    ingestStatus,
    statusReden,
    documenttype: typeUitkomst.documenttype,
    bronstatus: bronstatusUitkomst.bronstatus,
    bronstatusReden:
      (typeof raw.bronstatus_reden === "string" ? raw.bronstatus_reden.trim() : "") || null,
    bronstatusRagImpact: bronstatusUitkomst.ragImpact,
    retire,
    retireWaarschuwing,
  };
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json(
      { error: "Ongeldige aanvraag (verwacht JSON)." },
      { status: 400 }
    );
  }
  const mode = body.mode === "complete" ? "complete" : "init";
  return mode === "complete" ? completeUpload(req, body) : initUpload(req, body);
}

// ── init: gate de metadata + wijs een opslagpad toe (nog geen bestand/rij) ──
async function initUpload(req: NextRequest, body: Record<string, unknown>) {
  try {
    const supabase = await createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

    // Rate limiting (WP2): op de init-stap — de gate vóór de eigenlijke upload.
    const limiet = await controleerLimiet(supabase, LIMIETEN.upload);
    if (!limiet.toegestaan) return rateLimited("documents.upload", limiet.resetAt);

    const { data: profiel } = await supabase
      .from("profielen")
      .select("fonds_id, rol, naam")
      .eq("id", user.id)
      .single();
    if (!profiel?.fonds_id)
      return NextResponse.json({ error: "Geen fonds gekoppeld" }, { status: 400 });

    const hostOordeel = await beoordeelRouteHostToegang({
      sessieFondsId: profiel.fonds_id,
      gebruikerId: user.id,
      label: "documents.upload.init",
    });
    if (!hostOordeel.toegestaan)
      return NextResponse.json(
        { error: "Dit webadres hoort niet bij uw fonds." },
        { status: 403 }
      );

    const bestandsnaam = String(body.bestandsnaam ?? "");
    const grootte = Number(body.grootte ?? 0);

    // Aangekondigde grootte (client) — weiger een te groot bestand vóór de upload.
    // De echte bytecontrole gebeurt in complete op het gedownloade object.
    if (grootte > MAX_BESTAND_BYTES) {
      return badRequest(
        "documents.upload",
        `Het bestand is groter dan ${Math.round(MAX_BESTAND_BYTES / 1024 / 1024)} MB.`,
        413
      );
    }

    const ext = toegestaneUploadExtensie(bestandsnaam);
    if (!ext) {
      return NextResponse.json(
        {
          error: "Bestandstype niet ondersteund (alleen PDF, Word, PowerPoint of Excel).",
          foutcode: "type_niet_ondersteund",
        },
        { status: 400 }
      );
    }

    const meta = await valideerUploadMetadata(supabase, user.id, profiel.fonds_id, "init", {
      bestandsnaam,
      agendapunt_id: body.agendapunt_id as string | null,
      bibliotheek: body.bibliotheek as string | null,
      bron: body.bron as string | null,
      titel: body.titel as string | null,
      status: body.status as string | null,
      status_reden: body.status_reden as string | null,
      documenttype: body.documenttype as string | null,
      documentdatum: body.documentdatum as string | null,
      bronstatus: body.bronstatus as string | null,
      bronstatus_reden: body.bronstatus_reden as string | null,
      vervangt_rapportage_id: body.vervangt_rapportage_id as string | null,
      retire_reden: body.retire_reden as string | null,
    });
    if (!meta.ok) return meta.response;

    // Pad-conventie: <fonds_uuid>/<document_uuid>.<ext>. De storage-INSERT-policy
    // dwingt af dat de foldernaam het eigen fonds_id is; de client mint niets zelf.
    const document_id = randomUUID();
    const opslag_pad = `${profiel.fonds_id}/${document_id}.${ext}`;

    return NextResponse.json({ document_id, opslag_pad });
  } catch (error) {
    console.error("Upload-init fout:", error);
    return NextResponse.json(
      { error: "Er is een fout opgetreden bij het voorbereiden van de upload." },
      { status: 500 }
    );
  }
}

// ── complete: valideer het geüploade object + registreer de documentrij ─────
async function completeUpload(req: NextRequest, body: Record<string, unknown>) {
  // F0.1 — nulmeting-instrumentatie (metadata/tellingen, geen fondsinhoud/titel).
  const correlatieId = randomUUID();
  const tStart = Date.now();
  let validatieMs = 0;
  try {
    const supabase = await createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });

    const { data: profiel } = await supabase
      .from("profielen")
      .select("fonds_id, rol, naam")
      .eq("id", user.id)
      .single();
    if (!profiel?.fonds_id)
      return NextResponse.json({ error: "Geen fonds gekoppeld" }, { status: 400 });

    const hostOordeel = await beoordeelRouteHostToegang({
      sessieFondsId: profiel.fonds_id,
      gebruikerId: user.id,
      label: "documents.upload.complete",
    });
    if (!hostOordeel.toegestaan)
      return NextResponse.json(
        { error: "Dit webadres hoort niet bij uw fonds." },
        { status: 403 }
      );

    const document_id = String(body.document_id ?? "");
    const opslag_pad = String(body.opslag_pad ?? "");
    const bestandsnaam = String(body.bestandsnaam ?? "");
    const mimeType = String(body.mimeType ?? "");

    // Pad-autoriteit: het pad MOET exact <eigen fonds_id>/<document_id>.<ext> zijn.
    // Zo kan een client geen ander fonds-pad of losse uuid registreren; RLS is de
    // tweede linie (SELECT/INSERT-policies op het fondspad).
    const ext = toegestaneUploadExtensie(opslag_pad);
    if (
      !document_id ||
      !ext ||
      opslag_pad !== `${profiel.fonds_id}/${document_id}.${ext}`
    ) {
      return NextResponse.json(
        { error: "Ongeldig opslagpad voor deze upload.", foutcode: "opslagpad_ongeldig" },
        { status: 400 }
      );
    }

    const meta = await valideerUploadMetadata(supabase, user.id, profiel.fonds_id, "complete", {
      bestandsnaam,
      agendapunt_id: body.agendapunt_id as string | null,
      bibliotheek: body.bibliotheek as string | null,
      bron: body.bron as string | null,
      titel: body.titel as string | null,
      status: body.status as string | null,
      status_reden: body.status_reden as string | null,
      documenttype: body.documenttype as string | null,
      documentdatum: body.documentdatum as string | null,
      bronstatus: body.bronstatus as string | null,
      bronstatus_reden: body.bronstatus_reden as string | null,
      vervangt_rapportage_id: body.vervangt_rapportage_id as string | null,
      retire_reden: body.retire_reden as string | null,
    });
    if (!meta.ok) return meta.response;

    // Het object staat al in Storage (browser→Storage, RLS-afgedwongen). Haal het
    // server-side op — géén request-body-limiet — en draai de VOLLEDIGE validatie
    // (magic bytes, OOXML-subtype, zip-bom-budget, hash) vóórdat er een rij komt.
    const { data: blob, error: dlErr } = await supabase.storage
      .from("documenten")
      .download(opslag_pad);
    if (dlErr || !blob) {
      return NextResponse.json(
        {
          error:
            "Het geüploade bestand is niet gevonden. Probeer de upload opnieuw.",
          foutcode: "origineel_ontbreekt",
        },
        { status: 400 }
      );
    }
    const buffer = Buffer.from(await blob.arrayBuffer());

    // Vangnet naast de bucket-limiet (file_size_limit) en de client-check.
    if (buffer.length > MAX_BESTAND_BYTES) {
      return badRequest(
        "documents.upload",
        `Het bestand is groter dan ${Math.round(MAX_BESTAND_BYTES / 1024 / 1024)} MB.`,
        413
      );
    }

    const tValidatie = Date.now();
    const validatie = await valideerUpload({ naam: bestandsnaam, mimeType, buffer });
    validatieMs = Date.now() - tValidatie;
    if (!validatie.ok) {
      console.warn(
        `[documents.upload] geweigerd (${validatie.foutcode}) voor ${logNaam(bestandsnaam)}`
      );
      // Het afgekeurde object blijft als wees achter en wordt door de worker-
      // orphan-sweep opgeruimd (geen service-role op deze app-surface).
      const status =
        validatie.foutcode === "te_groot" || validatie.foutcode === "decompressie_cap"
          ? 413
          : 400;
      return NextResponse.json(
        { error: validatie.melding, foutcode: validatie.foutcode },
        { status }
      );
    }

    // De pad-extensie moet bij het gesnifte type passen. valideerUpload leidt het
    // type uit dezelfde bestandsnaam af, dus dit is een belt-and-braces-check.
    if (validatie.bestandstype !== ext) {
      return NextResponse.json(
        {
          error: "De bestandsextensie past niet bij de inhoud van het bestand.",
          foutcode: "extensie_inhoud_mismatch",
        },
        { status: 400 }
      );
    }

    // Deduplicatie op inhoudshash binnen het eigen fonds.
    const { data: bestaand } = await supabase
      .from("documenten")
      .select("id, titel")
      .eq("fonds_id", profiel.fonds_id)
      .eq("bestand_hash", validatie.hash)
      .eq("actief", true)
      .maybeSingle();
    if (bestaand) {
      return NextResponse.json(
        {
          error: `Dit bestand is al eerder geüpload als "${bestaand.titel}".`,
          foutcode: "duplicaat",
          document_id: bestaand.id,
        },
        { status: 409 }
      );
    }

    // Eén insert met opslag_pad ÉN verwerkingsstatus='ontvangen' (het reaper-
    // signaal). Atomair: de worker-reaper ziet het document nooit zonder
    // opslag_pad. `id` = de in init gemunte uuid, zodat rij en object matchen.
    const { data: document, error: docError } = await supabase
      .from("documenten")
      .insert({
        id: document_id,
        fonds_id: profiel.fonds_id,
        bibliotheek: meta.bibliotheek,
        bron: meta.bron,
        titel: meta.titel,
        bestandsnaam: validatie.veiligeNaam,
        bestand_hash: validatie.hash,
        bestandstype: validatie.bestandstype,
        paginas: null,
        opgeslagen_door: user.id,
        geindexeerd: false,
        opslag_pad,
        verwerkingsstatus: "ontvangen",
        agendapunt_id: meta.agendapunt_id,
        vergadering_id: meta.vergadering_id,
        // Werkopdracht 1.5 — afgeleide context (niet meer client-aangeleverd) en
        // 1.4/1.5 — documentdatum (rapportage verplicht, anders uploaddatum).
        context: meta.context,
        documentdatum: meta.documentdatum,
        ...(meta.ingestStatus ? { status: meta.ingestStatus } : {}),
        // Besluit 0140. Beide alleen meesturen als ze zijn verklaard: een
        // ontbrekend documenttype blijft NULL (restgroep "Zonder type") en een
        // ontbrekende bronstatus blijft NULL (≡ actief). Zo verandert er niets
        // aan het gedrag van de stromen die deze velden niet aanleveren.
        ...(meta.documenttype ? { documenttype: meta.documenttype } : {}),
        ...(meta.bronstatus ? { bronstatus: meta.bronstatus } : {}),
        // Werkopdracht 2.5 — `vervangt_document_id` wordt bewust NIET hier gezet,
        // maar pas ná een geslaagde retire (hieronder), zodat de FK-koppeling
        // symmetrisch is: geen claim op een vervanging die niet plaatsvond.
      })
      .select()
      .single();

    if (docError || !document) {
      // 23505 = dit document_id bestaat al (dubbele complete-aanroep). Idempotent
      // behandelen: de eerste aanroep heeft de rij al gemaakt.
      if (docError?.code === "23505") {
        return NextResponse.json({
          success: true,
          status: "verwerken",
          document_id,
          titel: meta.titel,
          bestandstype: validatie.bestandstype,
          bericht:
            "Document geüpload. Het wordt nu verwerkt en is binnen enkele minuten doorzoekbaar.",
        });
      }
      console.error("Fout bij opslaan document:", docError);
      return NextResponse.json(
        { error: "Kon document niet opslaan in database" },
        { status: 500 }
      );
    }

    // -- Auditregels bij een verklaring bij aanlevering, best-effort -----------
    // Statusverklaring: besluit 0136. Documenttype en bronstatus: besluit 0140.
    // Alle drie dragen `oude_waarde = 'upload'` — dát is het onderscheidende
    // kenmerk waaraan je in het log ziet dat de waarde bij AANLEVERING is
    // verklaard en niet later is gewijzigd.
    const auditRegels: Array<{
      veld_naam: string;
      nieuwe_waarde: string;
      wijzig_reden: string | null;
      wijzig_type: string;
      rag_impact: boolean;
    }> = [];
    if (meta.ingestStatus) {
      auditRegels.push({
        veld_naam: "status",
        nieuwe_waarde: meta.ingestStatus,
        wijzig_reden: meta.statusReden,
        wijzig_type: "status",
        rag_impact: true,
      });
    }
    if (meta.documenttype) {
      auditRegels.push({
        veld_naam: "documenttype",
        nieuwe_waarde: meta.documenttype,
        wijzig_reden: null,
        wijzig_type: "metadata",
        // documenttype staat in RAG_IMPACT_VELDEN (document-metadata.ts).
        rag_impact: true,
      });
    }
    if (meta.bronstatus) {
      auditRegels.push({
        veld_naam: "bronstatus",
        nieuwe_waarde: meta.bronstatus,
        wijzig_reden: meta.bronstatusReden,
        wijzig_type: "bronstatus",
        rag_impact: meta.bronstatusRagImpact,
      });
    }
    for (const regel of auditRegels) {
      const { error: auditFout } = await supabase.from("document_metadata_log").insert({
        document_id: document.id,
        document_titel_snapshot: meta.titel,
        fonds_id: profiel.fonds_id,
        gewijzigd_door: user.id,
        gewijzigd_door_naam: profiel.naam ?? null,
        oude_waarde: "upload",
        ...regel,
      });
      if (auditFout) {
        console.error(
          `[documents.upload] auditlog ${regel.veld_naam} mislukt voor ${document.id}:`,
          auditFout
        );
      }
    }

    // -- Rapportage-retire (werkopdracht 2.5), best-effort ----------------------
    // De gekozen voorganger → historisch (blijft historisch-vindbaar, valt uit
    // 'actueel'), daarna symmetrisch de vervangt/vervangen_door-FK's + auditregel.
    // De update draagt een STATUSGUARD (`.eq("status", verwachte)`) zodat een
    // race (de voorganger is tussen validatie en nu al afgevoerd/gewijzigd) 0
    // rijen raakt i.p.v. stil `historisch→historisch` te schrijven met een valse
    // auditregel. De DB-trigger valideert de overgang; de chunk-denorm schuift
    // mee. Faalt/mist de retire, dan blokkeert dat de geslaagde upload niet — er
    // gaat een waarschuwing terug. (Audit blijft best-effort, gelijk aan de
    // ingest-auditregels hierboven, 0136/0140.)
    let retireWaarschuwing: string | null = meta.retireWaarschuwing;
    if (meta.retire) {
      const { data: geraakt, error: retireFout } = await supabase
        .from("documenten")
        .update({
          status: "historisch",
          vervangen_door_document_id: document.id,
        })
        .eq("id", meta.retire.voorgangerId)
        // Statusguard: alleen afvoeren vanuit de gevalideerde actuele status.
        .eq("status", meta.retire.voorgangerOudeStatus)
        .select("id");
      if (retireFout || !geraakt || geraakt.length === 0) {
        if (retireFout) {
          console.error(
            `[documents.upload] rapportage-retire mislukt voor voorganger ${meta.retire.voorgangerId}:`,
            retireFout
          );
        }
        retireWaarschuwing =
          " Let op: de vorige rapportage kon niet worden afgevoerd (mogelijk inmiddels gewijzigd) — voer die handmatig af via 'Metadata bewerken'.";
      } else {
        // Symmetrische FK op de NIEUWE rapportage — pas nu de retire vaststaat.
        await supabase
          .from("documenten")
          .update({ vervangt_document_id: meta.retire.voorgangerId })
          .eq("id", document.id);
        for (const regel of [
          {
            veld_naam: "status",
            oude_waarde: meta.retire.voorgangerOudeStatus as string | null,
            nieuwe_waarde: "historisch",
            wijzig_type: "status",
            rag_impact: true,
          },
          {
            veld_naam: "vervangen_door_document_id",
            // De statusguard bevestigt dat de voorganger nog actueel (niet eerder
            // afgevoerd) was; zijn vervangen_door was dus null.
            oude_waarde: null as string | null,
            nieuwe_waarde: document.id,
            wijzig_type: "koppeling",
            rag_impact: false,
          },
        ]) {
          const { error: retireAuditFout } = await supabase
            .from("document_metadata_log")
            .insert({
              document_id: meta.retire.voorgangerId,
              document_titel_snapshot: meta.retire.voorgangerTitel,
              fonds_id: profiel.fonds_id,
              gewijzigd_door: user.id,
              gewijzigd_door_naam: profiel.naam ?? null,
              wijzig_reden: meta.retire.reden,
              ...regel,
            });
          if (retireAuditFout) {
            console.error(
              `[documents.upload] retire-auditlog ${regel.veld_naam} mislukt voor ${meta.retire.voorgangerId}:`,
              retireAuditFout
            );
          }
        }
      }
    }

    // F0.1: request-zijde meting (metadata only).
    console.log(
      JSON.stringify({
        tag: "ingest-meting",
        fase: "request",
        correlatie_id: correlatieId,
        document_id: document.id,
        fonds_id: profiel.fonds_id,
        bestandstype: validatie.bestandstype,
        agendapunt: !!meta.agendapunt_id,
        status: "verwerken",
        duur_ms: { validatie: validatieMs, totaal: Date.now() - tStart },
      })
    );

    const retireNoot =
      meta.retire && !retireWaarschuwing
        ? ` De vorige rapportage "${meta.retire.voorgangerTitel}" is afgevoerd naar historisch.`
        : retireWaarschuwing ?? "";

    return NextResponse.json({
      success: true,
      status: "verwerken",
      document_id: document.id,
      titel: meta.titel,
      bestandstype: validatie.bestandstype,
      bericht:
        "Document geüpload. Het wordt nu verwerkt en is binnen enkele minuten doorzoekbaar." +
        retireNoot,
    });
  } catch (error) {
    console.error("Upload-complete fout:", error);
    return NextResponse.json(
      { error: "Er is een fout opgetreden bij het uploaden." },
      { status: 500 }
    );
  }
}


// Haal lijst van documenten op
export async function GET(req: NextRequest) {
  try {
    const supabase = await createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const bibliotheek = searchParams.get("bibliotheek");

    let query = supabase
      .from("documenten")
      .select("*")
      .order("aangemaakt", { ascending: false });

    if (bibliotheek) {
      query = query.eq("bibliotheek", bibliotheek);
    }

    const { data, error } = await query;
    if (error) {
      console.error("Documenten ophalen fout:", error);
      return NextResponse.json({ error: "Documenten ophalen mislukt" }, { status: 500 });
    }
    return NextResponse.json({ documenten: data });
  } catch (error) {
    console.error("Fout bij ophalen documenten:", error);
    return NextResponse.json({ error: "Serverfout" }, { status: 500 });
  }
}
