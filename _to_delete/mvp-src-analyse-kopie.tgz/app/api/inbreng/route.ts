import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/core/lib/supabase-server";
import { notifyUser } from "@/core/lib/notifications";

export async function POST(req: NextRequest) {
  try {
    const supabase = await createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });
    }

    const body = (await req.json()) as {
      agendapunt_id?: string;
      tekst?: string;
    };
    const { agendapunt_id, tekst } = body;

    if (!agendapunt_id || !tekst || tekst.trim().length === 0) {
      return NextResponse.json(
        { error: "agendapunt_id en tekst zijn verplicht" },
        { status: 400 }
      );
    }

    const { data: profiel } = await supabase
      .from("profielen")
      .select("naam, fonds_id")
      .eq("id", user.id)
      .single();

    const { data, error } = await supabase
      .from("agendapunt_inbreng")
      .insert({
        agendapunt_id,
        gebruiker_id: user.id,
        gebruiker_naam: profiel?.naam || user.email,
        tekst: tekst.trim(),
      })
      .select()
      .single();

    if (error) {
      console.error("Inbreng toevoegen fout:", error);
      return NextResponse.json({ error: "Inbreng toevoegen mislukt" }, { status: 500 });
    }

    // ── Iteratie 3-A: notificatie naar de vergadering-organisator ──
    // Bewust niet aan álle bestuursleden geüpdaten — dat zou de homepage
    // overspoelen bij een drukke vergadering. De organisator is degene
    // die zicht houdt op de voorbereiding van de vergadering en
    // baat heeft bij signaal "iemand heeft input geleverd".
    if (profiel?.fonds_id) {
      const { data: agendapunt } = await supabase
        .from("agendapunten")
        .select("titel, vergadering_id, vergaderingen(aangemaakt_door)")
        .eq("id", agendapunt_id)
        .maybeSingle();

      const vergRel = agendapunt?.vergaderingen as
        | { aangemaakt_door: string | null }
        | { aangemaakt_door: string | null }[]
        | null
        | undefined;
      const vergObj = Array.isArray(vergRel) ? vergRel[0] : vergRel;
      const organisatorId = vergObj?.aangemaakt_door ?? null;

      if (organisatorId && agendapunt?.titel && agendapunt.vergadering_id) {
        await notifyUser(
          supabase,
          "inbreng_geplaatst",
          organisatorId,
          profiel.fonds_id,
          {
            type: "inbreng_geplaatst",
            agendapunt_titel: agendapunt.titel,
            actor_naam: profiel.naam || user.email || "Een collega",
            vergadering_id: agendapunt.vergadering_id,
          },
          {
            gerelateerd_aan_type: "agendapunt",
            gerelateerd_aan_id: agendapunt_id,
            actor_naam: profiel.naam || null,
          }
        );
      }
    }

    return NextResponse.json({ inbreng: data });
  } catch (e) {
    console.error("Fout in /api/inbreng:", e);
    return NextResponse.json({ error: "Serverfout" }, { status: 500 });
  }
}
