"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const CATEGORIEEN: { value: string; label: string }[] = [
  { value: "beeldvorming", label: "Beeldvorming" },
  { value: "oordeelsvorming", label: "Oordeelsvorming" },
  { value: "besluitvorming", label: "Besluitvorming" },
  { value: "informatie", label: "Informatie" },
];

export default function NieuwAgendapuntForm({ vergaderingId }: { vergaderingId: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [bezig, setBezig] = useState(false);
  const [fout, setFout] = useState<string | null>(null);

  const [titel, setTitel] = useState("");
  const [beschrijving, setBeschrijving] = useState("");
  const [categorie, setCategorie] = useState("informatie");
  const [tijdsduur, setTijdsduur] = useState("");
  const [verantwoordelijke, setVerantwoordelijke] = useState("");

  async function indienen(e: React.FormEvent) {
    e.preventDefault();
    if (!titel.trim()) {
      setFout("Titel is verplicht.");
      return;
    }
    setBezig(true);
    setFout(null);
    try {
      const res = await fetch("/api/agendapunten", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          vergadering_id: vergaderingId,
          titel: titel.trim(),
          beschrijving: beschrijving.trim() || undefined,
          categorie,
          tijdsduur_minuten: tijdsduur ? parseInt(tijdsduur, 10) : undefined,
          verantwoordelijke: verantwoordelijke.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFout(data.error || "Er is een fout opgetreden.");
        return;
      }
      setTitel("");
      setBeschrijving("");
      setCategorie("informatie");
      setTijdsduur("");
      setVerantwoordelijke("");
      setOpen(false);
      router.refresh();
    } catch {
      setFout("Verbindingsfout. Probeer het opnieuw.");
    } finally {
      setBezig(false);
    }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="text-sm text-ink border border-app-line-strong rounded-lg px-3 py-1.5 hover:border-accent transition-colors"
      >
        + Agendapunt toevoegen
      </button>
    );
  }

  return (
    <form
      onSubmit={indienen}
      className="bg-white border border-line rounded-xl p-4 w-full"
    >
      <div className="text-sm font-semibold text-ink mb-3">Nieuw agendapunt</div>
      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted block mb-1">Titel</label>
          <input
            type="text"
            value={titel}
            onChange={(e) => setTitel(e.target.value)}
            placeholder="Bijv. Concept jaarverslag 2025 vaststellen"
            className="w-full border border-line rounded-lg px-3 py-2 text-sm bg-app-bg outline-none focus:border-accent"
          />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs text-muted block mb-1">Categorie</label>
            <select
              value={categorie}
              onChange={(e) => setCategorie(e.target.value)}
              className="w-full border border-line rounded-lg px-3 py-2 text-sm bg-app-bg outline-none focus:border-accent"
            >
              {CATEGORIEEN.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs text-muted block mb-1">Tijdsduur (min)</label>
            <input
              type="number"
              value={tijdsduur}
              onChange={(e) => setTijdsduur(e.target.value)}
              placeholder="30"
              min={5}
              max={300}
              className="w-full border border-line rounded-lg px-3 py-2 text-sm bg-app-bg outline-none focus:border-accent"
            />
          </div>
          <div>
            <label className="text-xs text-muted block mb-1">Verantwoordelijke</label>
            <input
              type="text"
              value={verantwoordelijke}
              onChange={(e) => setVerantwoordelijke(e.target.value)}
              placeholder="Bijv. Voorzitter"
              className="w-full border border-line rounded-lg px-3 py-2 text-sm bg-app-bg outline-none focus:border-accent"
            />
          </div>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Korte beschrijving</label>
          <textarea
            value={beschrijving}
            onChange={(e) => setBeschrijving(e.target.value)}
            rows={2}
            placeholder="Optionele toelichting voor het bestuur."
            className="w-full border border-line rounded-lg px-3 py-2 text-sm bg-app-bg outline-none focus:border-accent resize-none"
          />
        </div>

        {fout && <div className="text-sm text-err-ink">{fout}</div>}

        <div className="flex gap-2">
          <button
            type="submit"
            disabled={bezig}
            className="bg-accent text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-accent hover:text-ink transition-colors disabled:opacity-50"
          >
            {bezig ? "Bezig..." : "Toevoegen"}
          </button>
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              setFout(null);
            }}
            className="text-sm text-muted hover:text-ink px-3 py-2"
          >
            Annuleren
          </button>
        </div>
      </div>
    </form>
  );
}
